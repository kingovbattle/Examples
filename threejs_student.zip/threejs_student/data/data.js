{
    "pointsOfInterest": [
        { "x": 1, "y": 0, "title": "Dog Show" },
        { "x": 2, "y": 2, "title": "Cat Show" }
    ]
}